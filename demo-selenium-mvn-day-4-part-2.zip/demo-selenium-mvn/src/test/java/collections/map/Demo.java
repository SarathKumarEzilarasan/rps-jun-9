package collections.map;

import java.util.*;

public class Demo {
    // Map -> HashMap,LinkedHashMap,TreeMap
    public static void main(String[] args) {
//        Map<String, Integer> map = new TreeMap<>();
//
//        map.put("john", 119290202);
//        map.put("peter", 119290202);
//        map.put("zack", 444444444);


//        System.out.println(map.get("john"));
//        map.remove("john");
//        System.out.println(map);
//        System.out.println(map.size());
//        System.out.println(map.containsKey("peter"));
//        System.out.println(map.containsValue(444444444));

//        Set<String> keys = map.keySet();
//
//        for (String key:keys){
//            System.out.println(key);
//        }

//        Collection<Integer> values = map.values();
//        for (Integer value : values) {
//            System.out.println(value);
//        }

//        Set<Map.Entry<String, Integer>> entries = map.entrySet();
//
//        for (Map.Entry<String, Integer> entry : entries) {
//            System.out.println(entry.getKey());
//            System.out.println(entry.getValue());
//        }

        characterFrequency("wwwaabbc");
    }

    // wwwaabbc -> w3a2b2c1
    public static void characterFrequency(String s) {
        Map<Character, Integer> map = new LinkedHashMap<>();

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (map.containsKey(ch)) {
                int oldValue = map.get(ch);
                map.put(ch, oldValue + 1);
            } else {
                map.put(ch, 1);
            }
        }

        System.out.println(map);
    }
}
