package collections;

import java.util.ArrayList;

public class WrapperClasses {
    public static void main(String[] args) {
        int i = 100;
        Integer j = 100;


        Float f = 100f;

//        System.out.println(Integer.parseInt("10"));


        Integer a = Integer.valueOf(128);
        Integer b = 128;

//        Long.valueOf();

        System.out.println(a == b);

    }
}
