package collections.list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

    // List , Set , Map

    public static void main(String[] args) {
        // data structure -> Create Add Read Update Delete Search
        // Generics
        List<Integer> arrayList = new ArrayList<>(100); // 75% -> double the size (20) -> 40
        arrayList.add(10);
        arrayList.add(10);
        arrayList.add(10);
        arrayList.add(10);
        arrayList.add(10);

//        arrayList.add("hello world");

        arrayList.remove(1);

        arrayList.set(1, 20);
        System.out.println(arrayList.get(1));

        System.out.println(arrayList.contains(10));

        int x = 100;

        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i) == x) {
                System.out.println("found x");
            }
        }
    }
}

// LinkedList