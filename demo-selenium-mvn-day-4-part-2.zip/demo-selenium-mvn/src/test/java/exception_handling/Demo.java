package exception_handling;

public class Demo {
    public static void main(String[] args) { //throws Exception{
//        try {
//            System.out.println(1 / 0);
//        } catch (Exception e) {
//            System.out.println("from catch block");
//            e.printStackTrace();
//        }
//
//        System.out.println("hello world");

//        try {
//            System.out.println(1);
//        } catch (Exception e) {
//            System.out.println("from catch block");
//            e.printStackTrace();
//        }
//
//        System.out.println("hello world");

//        try {
//            System.out.println("".charAt(10));
//
//        } catch (ArithmeticException e) {
//            System.out.println("from ArithmeticException catch block");
//        } catch (Exception e) {
//            System.out.println("from Exception catch block");
//        }
        try {
            isValidAge(10);
        } catch (Exception e) {
            System.out.println("from catch");
        }

    }

    public static void isValidAge(int age) throws Exception {
        if (age >= 18) {
            System.out.println("valid age");
        } else {
            throw new Exception("invalid age");
        }
    }
}
