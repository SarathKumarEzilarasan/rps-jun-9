package oops.inheritance;

public class TataSedan extends Tata{
}
