package oops.inheritance;

public class Tata extends Car{

}
