package oops.polymorphism.overriding;

public class Tata extends Car {

}
