package oops.polymorphism.overloading;

public class Overloading {

    public static void main(String[] args) {
        add(100, 200);
        add(100f, 100);
        add(100, 200, 300);
    }

    public static void add(int a, int b) {
        System.out.println(a + b);
    }

//    public static int add(int a, int b) {
//        System.out.println(a + b);
//        return 0;
//    }


    public static void add(float a, int b) {
        System.out.println(a + b);
    }

    public static void add(int a, int b, int c) {
        System.out.println(a + b + c);
    }
}
// method name + no. of function parameters/ type of function parameters