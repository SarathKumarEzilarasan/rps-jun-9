package oops.abstraction.abstract_class;

public class Bmw implements Car {
    public void breaks() {
        System.out.println("Advanced breaking system");
    }

    public void sunroof() {
        System.out.println("sunroof");
    }
}
