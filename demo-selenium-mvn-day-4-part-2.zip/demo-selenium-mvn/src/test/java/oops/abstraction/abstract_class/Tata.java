package oops.abstraction.abstract_class;

public class Tata implements Car {
    public void breaks() {
        System.out.println("tata breaking system");
    }
}
