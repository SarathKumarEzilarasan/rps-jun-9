package oops.abstraction.abstract_class;

public class Test {
    public static void main(String[] args) {
        Tata tata = new Tata();
        tata.breaks();


        Bmw bmw = new Bmw();
        bmw.breaks();


//        Fiat fiat = new FiatSedan();
//        fiat.breaks();
    }
}
