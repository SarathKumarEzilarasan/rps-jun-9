package constructors;

public class Test {
    public static void main(String[] args) {
//        Student john = new Student("hey");
//        john.setName("john");
//        john.setAge(20);
//        john.setContactInfo("someone");


//        Student john = new Student("john", 20, "someone");
//        System.out.println(john.getAge());


        FullTimeStudent fullTimeStudent =
                new FullTimeStudent("john", 20, "someone", "12:00PM", 10000, "CSC");

        System.out.println(fullTimeStudent.getAge());
    }
}
