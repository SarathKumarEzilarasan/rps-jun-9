package access_modifier.test;

public class Test {
    public static void main(String[] args) {
        User user = new User();
        System.out.println(user.password);
        System.out.println(user._password);
        System.out.println(user.username);
    }
}
