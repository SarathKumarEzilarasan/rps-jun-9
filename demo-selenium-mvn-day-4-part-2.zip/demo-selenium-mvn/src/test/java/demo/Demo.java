package demo;

public class Demo {

    static int x = 1000;
    int y = 2000;
}
