package demo;

public class Loops {
    public static void main(String[] args) {
        // loops -> while , for , do while

//        int counter = 3;
//        while (counter > 0) {
//            System.out.println(counter);
//            counter--;
//        }

//        for (int counter = 0; counter > 0; counter--) {
//            System.out.println(counter);
//        }

//        int counter = 0;
//        do {
//            System.out.println(counter);
//            counter--;
//        } while (counter > 0);


//        for (int i = 1; i <= 5; i++) {
//            System.out.println(i);
//        }

//        for (int i = 1; i <= 5; i++) {     //    1[5],2[5],3[5],4[5],5[5]
//            for (int j = 1; j <= i; j++) {
//                System.out.print(j);
//            }
//            System.out.println();
//        }

//        for (int i = 1; i <= 5; i++) {     //    1[5],2[5],3[5],4[5],5[5]
//            for (int j = 1; j <= 5 - i; j++) {
//                System.out.print(j);
//            }
//            System.out.println();
//        }




    }
}
