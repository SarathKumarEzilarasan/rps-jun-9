package array;

public class Demo {
    public static void main(String[] args) {
        // data structure -> Create Add Read Update Delete Search
        int[] arr = new int[5];
//        System.out.println(arr[0]);

        for (int i = 0; i < arr.length; i++) {
            arr[i] = i * 100;
        }
//        System.out.println(arr[3]);

//        int x = 100;
//
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i] == x) {
//                System.out.println("found x");
//            }
//        }

//        System.out.println(arr[10]);


        System.out.println(arr[3]);

        int[] temp = new int[5];
        for (int i = 0; i < arr.length; i++) {
            temp[i] = arr[i];
        }

        arr = new int[6];
        for (int i = 0; i < temp.length; i++) {
            arr[i] = temp[i];
        }

        System.out.println(arr[3]);


    }
}

// fixed size -> Array List