package oops.encapsulation;

public class User {
    public String username;
    private String password = "user@123";

    // getter
    public String getPassword() {
        return password;
    }

    // setter
    public void setPassword(String password) {
//        password = password;
        this.password = password;
    }
}
