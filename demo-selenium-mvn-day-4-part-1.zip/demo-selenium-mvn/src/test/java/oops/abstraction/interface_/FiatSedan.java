package oops.abstraction.interface_;

public class FiatSedan extends Fiat {
    public void breaks() {

    }
}
