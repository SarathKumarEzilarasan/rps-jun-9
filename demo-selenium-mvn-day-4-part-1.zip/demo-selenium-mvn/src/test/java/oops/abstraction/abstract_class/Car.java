package oops.abstraction.abstract_class;

public interface Car {

    void breaks();

}
