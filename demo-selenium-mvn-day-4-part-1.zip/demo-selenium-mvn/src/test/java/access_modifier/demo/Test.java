package access_modifier.demo;

import access_modifier.test.User;

public class Test {
    public static void main(String[] args) {
        User user = new User();
//        System.out.println(user.password);
//        System.out.println(user._password);
        System.out.println(user.username);
    }
}
