package collections;

public class WrapperClasses {
    public static void main(String[] args) {
        int i = 100;
        Integer j = 100;


        Float f = 100f;

        System.out.println(Integer.parseInt("10"));


    }
}
