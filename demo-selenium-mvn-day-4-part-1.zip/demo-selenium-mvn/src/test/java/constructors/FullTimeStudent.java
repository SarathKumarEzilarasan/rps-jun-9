package constructors;

public class FullTimeStudent extends Student {

    private String timings;
    private int fee;
    private String courses;

    public FullTimeStudent(String name, int age, String contactInfo, String timings, int fee, String courses) {
        super(name, age, contactInfo); // calling parent constructor
        this.timings = timings;
        this.fee = fee;
        this.courses = courses;
    }

    public String getTimings() {
        return timings;
    }

    public void setTimings(String timings) {
        this.timings = timings;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public String getCourses() {
        return courses;
    }

    public void setCourses(String courses) {
        this.courses = courses;
    }
}
