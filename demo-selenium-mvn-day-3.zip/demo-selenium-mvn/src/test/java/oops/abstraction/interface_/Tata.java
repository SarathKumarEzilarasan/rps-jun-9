package oops.abstraction.interface_;

public class Tata extends Car {
    public void breaks() {
        System.out.println("tata breaking system");
    }
}
