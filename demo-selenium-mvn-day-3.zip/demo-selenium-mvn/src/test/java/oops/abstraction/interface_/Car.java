package oops.abstraction.interface_;

public abstract class Car {
    public int price = 100000;

    public abstract void breaks();

    public void sunroof(){

    }
}
