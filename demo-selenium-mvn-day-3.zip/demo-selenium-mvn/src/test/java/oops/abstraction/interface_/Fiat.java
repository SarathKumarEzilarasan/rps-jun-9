package oops.abstraction.interface_;

public abstract class Fiat extends Car {

}
