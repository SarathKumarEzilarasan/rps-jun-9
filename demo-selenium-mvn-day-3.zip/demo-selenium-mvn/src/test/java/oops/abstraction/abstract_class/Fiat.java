package oops.abstraction.abstract_class;

//public abstract class Fiat extends Car {
//
//}
