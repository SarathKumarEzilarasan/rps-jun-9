package oops.abstraction.abstract_class;

//public class FiatSedan extends Fiat {
//    public void breaks() {
//
//    }
//}
