package oops.inheritance;

public class Test {
    public static void main(String[] args) {
        Tata tata = new Tata();
        tata.breaks();
        System.out.println(tata.price);

        Bmw bmw = new Bmw();
        bmw.breaks();

        TataSedan tataSedan = new TataSedan();
        tataSedan.breaks();
    }
}

// one level inheritance
// multi level inheritance
// multiple inheritance ---> ?????????