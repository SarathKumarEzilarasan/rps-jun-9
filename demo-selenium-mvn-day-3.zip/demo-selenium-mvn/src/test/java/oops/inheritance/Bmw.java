package oops.inheritance;

public class Bmw extends Car{

}
