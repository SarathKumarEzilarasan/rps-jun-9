package oops.polymorphism.overriding;

public class Test {
    public static void main(String[] args) {
//        Tata tata = new Tata();
//        tata.breaks();


//        Bmw bmw = new Bmw();
//        bmw.breaks();
//        bmw.sunroof();

//        Tata tata;
//        Bmw bmw;
//
        String s = "chrome";
//
//        if (s.equals("chrome")){
//            tata = new Tata();
//            tata.breaks();
//        }else {
//            bmw = new Bmw();
//            bmw.breaks();
//        }


        Car car;
        if (s.equals("chrome")) {
            car = new Tata();
        } else {
            car = new Bmw();
//            car.sunroof();
        }

        car.breaks();

    }
}
