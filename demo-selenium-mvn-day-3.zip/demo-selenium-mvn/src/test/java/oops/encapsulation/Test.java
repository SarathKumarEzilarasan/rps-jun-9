package oops.encapsulation;

public class Test {
    public static void main(String[] args) {
        User user = new User();
        System.out.println(user.getPassword());
        user.setPassword("test@123");
        System.out.println(user.getPassword());
    }
}
