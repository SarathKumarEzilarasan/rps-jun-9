package demo;

public class Variables {

    // main method/ main function
    public static void main(String[] args) {
        // variables -> x = 100 , y = 200 , x+y = 300
        // data types -> primitive -> stack , non primitive -> heap
        // byte    -> whole numbers -> 1 byte  -> -128 to 127
        // short   -> whole numbers -> 2 bytes -> -32k to 32k
        // integer -> whole numbers -> 4 bytes -> -2*10(9) to 2*10(9)
        // long    -> whole numbers -> 8 bytes -> -2*10(63) to 2*10(63)
        // float   -> decimal numbers -> 4 bytes -> 5 decimal digits
        // double  -> decimal numbers -> 8 bytes -> 15 decimal digits
        // boolean
        // char
        // String


        // byte -> short -> integer

        // type casting -> implicit , explicit
        // int -> long
//
//
//        int x = 100;
//
//        long l = x;
//
//        int y = (int) l;
//
//        System.out.println(y);

        // long l = 10005450000l;


        // float f = l;


        // System.out.println(f);

        char c = 'a';
        String s = "sjkfskjdfjk skdjfksdfk";

    }
}

// heap , stack