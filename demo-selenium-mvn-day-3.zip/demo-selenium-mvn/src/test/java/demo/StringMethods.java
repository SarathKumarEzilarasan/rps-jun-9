package demo;

public class StringMethods {
    public static void main(String[] args) {
        // string intern pool
        // strings are immutable
//        String s1 = "hello world"; // 1 GB
//        String s2 = "hello world"; // 1 GB ???
//        String s3 = new String("hello world");


//        System.out.println(s1.equals(s3));
//        System.out.println(s1.toUpperCase());
//        s1 = "hello earth";
//        System.out.println(s1);

//        System.out.println(s1.toLowerCase());
        String s1 = "hello world"; // 1 GB
        //           012345678910 --> indexes or locations


//        System.out.println(s1.charAt(1));
//        System.out.println(s1.indexOf("e"));
//        System.out.println(s1.lastIndexOf("l"));
//        System.out.println(s1.startsWith("hel"));
//        System.out.println(s1.endsWith("hel"));
//        System.out.println(s1.contains("o w"));
//        System.out.println(s1.substring(4,8));
//        System.out.println(s1.replace("l","z"));
//        System.out.println(s1.trim());


//        System.out.println(s1.split());

//        for (int i = 0; i < s1.length() ; i++) {
//            System.out.println(s1.charAt(i));
//        }

//        System.out.println(s1.charAt(s1.length() - 1));


        isPalindrome("hello world");
        //              012345678910
        isPalindrome("madam");
    }

    // madam
    public static void isPalindrome(String str) {
        // reverse
        // compare

        String reverse = ""; //

        for (int i = str.length() - 1; i >= 0; i--) {
            char ch = str.charAt(i);
            reverse = reverse + ch;
            //         ""  + d -> d
            //         d   + l -> dl
            //         dl  + r -> dlr
        }

        if (str.equals(reverse)) {
            System.out.println("palindrome");
        } else {
            System.out.println("not a palindrome");
        }
    }


}

// strings are immutable