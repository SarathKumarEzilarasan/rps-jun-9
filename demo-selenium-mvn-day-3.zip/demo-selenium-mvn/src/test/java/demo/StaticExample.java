package demo;

public class StaticExample {

    static int x = 1000; // global/class variable
    int y = 2000;

    public static void main(String[] args) {
//        int x = 100; // local variables

//        Demo d1 = new Demo();
//        d1.y = 100;
//        Demo d2 = new Demo();
//        d2.y = 200;
//        System.out.println(d1.y);
//        System.out.println(d2.y);

//        Demo d1 = new Demo();
//        d1.x = 100;
//        Demo d2 = new Demo();
//        d2.x = 200;
//        System.out.println(Demo.x);
//        System.out.println(Demo.y);

        System.out.println(x);

        StaticExample staticExample = new StaticExample();
        System.out.println(staticExample.y);
        staticExample.add();

    }

    public void add() {
        System.out.println(x);
        System.out.println(y);
    }

}

// static function
    // you can access static variables/methods
    // to access non static variables/methods we need to create an object

// non static function
   // you can access static variables/methods and also non static variables/methods