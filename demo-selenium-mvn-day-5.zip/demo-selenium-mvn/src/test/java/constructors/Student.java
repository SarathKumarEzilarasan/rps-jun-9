package constructors;

public class Student {

    // default constructor
    public Student() {
        System.out.println("hello");
    }

    // parameterised constructor
    public Student(String s) {
        System.out.println(s);
    }

    public Student(String name, int age, String contactInfo) {
        this.name = name;
        this.age = age;
        this.contactInfo = contactInfo;
    }

    private String name;
    private int age;
    private String contactInfo;

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
}
