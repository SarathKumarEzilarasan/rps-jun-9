package access_modifier.demo;

import access_modifier.test.User;

import java.util.Scanner;

public class Demo extends User {
    public static void main(String[] args) {
//        User user = new User();
//        System.out.println(user._password);
//        System.out.println(user.username);


        Scanner scanner = new Scanner(System.in);

        int i = scanner.nextInt();
        int j = scanner.nextInt();

        System.out.println(i);
        System.out.println(j);

    }
}
