package oops.polymorphism.overriding;

public class Bmw extends Car {
    public void breaks() {
        System.out.println("Advanced breaking system");
    }

    public void sunroof() {
        System.out.println("sunroof");
    }
}
