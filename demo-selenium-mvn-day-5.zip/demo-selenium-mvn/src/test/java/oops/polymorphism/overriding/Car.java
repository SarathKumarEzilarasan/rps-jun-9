package oops.polymorphism.overriding;

public class Car {
    public int price = 100000;
    public void breaks() {
        System.out.println("breaking system");
    }
}
