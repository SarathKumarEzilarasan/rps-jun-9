package file_handling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class Demo {
    public static void main(String[] args) {
        // Create write read update delete
        String filePath = "/Users/preethir/Downloads/rps-jun-9/demo-selenium-mvn/demo.txt";
        Path path = Path.of(filePath);
        try {
//            Files.createFile(path);
//            Files.writeString(path, "hello world", StandardOpenOption.WRITE);
            System.out.println(Files.readAllLines(path));
//            Files.writeString(path, " from java", StandardOpenOption.APPEND);
//            Files.delete(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
