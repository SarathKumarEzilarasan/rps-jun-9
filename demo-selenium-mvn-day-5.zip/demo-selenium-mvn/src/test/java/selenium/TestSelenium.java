package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestSelenium {
    // main function or main method
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver(); // Overriding
        driver.get("https://www.google.com/");
        // locators
//        By by = By.id("APjFqb");
//        By by = By.className("gLFyf");
//        By by = By.name("q");
//        By by = By.tagName("textarea");
//        By by = By.linkText("textarea");
//        By by = By.partialLinkText("textarea");
//        By by = By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div[1]/div[2]/textarea");
//        By by = By.xpath("//textarea[@id=‘APjFqb’]");
//        By by = By.xpath("//textarea[@id='APjFqb' or @class='gLFyf']");
//        By by = By.xpath("//textarea[@id='APjFqb' and @class='gLFyf']");
//        By by = By.xpath("//textarea[text()='hello']");
//        By by = By.xpath("//div[starts-with(@jsmodel,'VYkzu')]");
        By by = By.cssSelector("textarea[id='APjFqb']");

        WebElement textBox = driver.findElement(by);
        textBox.sendKeys("selenium with java");


    }
}
