package object;

public class Demo {
    public static void main(String[] args) {
        Student s1 = new Student("john", 19, "dummy");
        Student s2 = new Student("john", 19, "dummy");

//        System.out.println(john);

//        System.out.println(s1.equals(s2));

        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());

    }
}
