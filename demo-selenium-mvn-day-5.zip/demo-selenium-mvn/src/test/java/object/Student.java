package object;

public class Student {

    // default constructor
    public Student() {
        System.out.println("hello");
    }

    // parameterised constructor
    public Student(String s) {
        System.out.println(s);
    }

    public Student(String name, int age, String contactInfo) {
        this.name = name;
        this.age = age;
        this.contactInfo = contactInfo;
    }

    private String name;
    private int age;
    private String contactInfo;

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String toString() {
        return "Student Name: " + this.name + " age: " + this.age + " contact info: " + this.contactInfo;
    }

    public boolean equals(Object obj) {
        Student s2 = (Student) obj;
        boolean nameFlag = this.name.equals(s2.getName());
        boolean ageFlag = this.age == s2.getAge();
        boolean contactInfoFlag = this.contactInfo.equals(s2.getContactInfo());

        return nameFlag && ageFlag && contactInfoFlag;
    }

    public int hashCode() {
        return this.name.length() * 4 + this.age + this.contactInfo.length() * 10;
    }


}
