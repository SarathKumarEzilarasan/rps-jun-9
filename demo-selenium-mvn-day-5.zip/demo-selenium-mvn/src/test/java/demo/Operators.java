package demo;

public class Operators {
    public static void main(String[] args) {
        // operators -> + - * / % == != > < >= <= ++ -- >> <<

        int x = 100;


    }
}
