package demo;

public class Functions {
    // main function/method
    public static void main(String[] args) {
        //  add(100,200);// function call or function invocation

        // x+y-z
        int x = 100;
        int y = 200;
        int z = 300;

        int sum = add(x, y);

        System.out.println(sum - z);
    }

    // custom function or user defined function
    public static int add(int a, int b) { // function parameters
        int x = a;
        int y = b;
//        System.out.println(x + y);

        return x + y;
    }


}
