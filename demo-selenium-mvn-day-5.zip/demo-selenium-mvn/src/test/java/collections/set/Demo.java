package collections.set;

import java.util.*;

public class Demo {
    // Set -> Unique Values -> HashSet, LinkedHashSet , TreeSet
    public static void main(String[] args) {
//        List<Integer> list = new ArrayList<>();
//        list.add(1000111);
//        list.add(2000111);
//        list.add(1000111);
//        list.add(2000111);
//        System.out.println(list);

//        Set<Integer> set = new HashSet<>();
//        set.add(1000111);
//        set.add(2000111);
//        set.add(1000111);
//        set.add(2000111);

//        set.remove(1000111);
//        System.out.println(set.contains(200));
//        System.out.println(set.size());

//        for (Integer i : set) {
//            System.out.println(i);
//        }

//        List<Integer> list = new ArrayList<>(set);
//        System.out.println(list.get(1));


//        Set<String> set = new HashSet<>();
        Set<String> set = new TreeSet<>();

        set.add("john");
        set.add("adam");
        set.add("zack");

        System.out.println(set);
    }
}

// HashSet -> Hashing -> j*10(3) + o*10(2) + h*10(1) + n*10(0) --> 10000