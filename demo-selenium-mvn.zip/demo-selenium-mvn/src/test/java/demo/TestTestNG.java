package demo;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestTestNG {

    WebDriver driver;

    @BeforeTest
    public void setUp() {
        driver = new ChromeDriver(); // local variable
    }

    @Test
    public void textBoxTest() {
        driver.get("https://www.leafground.com/input.xhtml");
//        By by = By.xpath("//input[@id='j_idt88:name']");
//        WebElement inputBox = driver.findElement(by);
//        inputBox.sendKeys("hello world");

        driver.findElement(By.xpath("//input[@id='j_idt88:name']")).sendKeys("hello world");
        driver.findElement(By.xpath("//input[@name='j_idt88:j_idt91']")).sendKeys(" India");


        boolean status = driver.findElement(By.xpath("//input[@id='j_idt88:j_idt93']")).isEnabled();

        Assert.assertEquals(status, false);

        driver.findElement(By.xpath("//input[@name='j_idt88:j_idt95']")).clear();
        driver.findElement(By.xpath("//input[@name='j_idt88:j_idt95']")).sendKeys("Hyderabad");

        String value = driver.findElement(By.xpath("//input[@id='j_idt88:j_idt97']")).getDomAttribute("value");
        System.out.println(value);

        driver.findElement(By.name("j_idt88:j_idt99")).sendKeys("hello there !!!");
        driver.findElement(By.name("j_idt88:j_idt99")).sendKeys(Keys.TAB);

    }

    @Test
    public void buttonTest() throws InterruptedException {
        driver.get("https://www.leafground.com/button.xhtml");
        driver.findElement(By.xpath("//button[@name='j_idt88:j_idt90']")).click();
        String currentUrl = driver.getCurrentUrl();
        boolean verifyUrl = currentUrl.startsWith("https://www.leafground.com/dashboard.xhtml");
        Assert.assertEquals(verifyUrl, true);

        driver.get("https://www.leafground.com/button.xhtml");
        boolean enabled = driver.findElement(By.name("j_idt88:j_idt92")).isEnabled();
        Assert.assertEquals(enabled, false);

        Point point = driver.findElement(By.id("j_idt88:j_idt94")).getLocation();
        Assert.assertEquals(point.getX(), 81);
        Assert.assertEquals(point.getY(), 400);

        String colour = driver.findElement(By.id("j_idt88:j_idt96")).getCssValue("background");
        boolean colourStatus = colour.startsWith("rgb(96, 125, 139)");
        Assert.assertEquals(colourStatus, true);

        Dimension dimension = driver.findElement(By.name("j_idt88:j_idt98")).getSize();

        Assert.assertEquals(dimension.getHeight(), 34);
        Assert.assertEquals(dimension.getWidth(), 87);

        driver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("j_idt88:j_idt107")).click();
    }

    //@AfterTest
    public void tearDown() {
        driver.quit();
    }
}
