package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.TextBoxPage;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class BaseTest {
    WebDriver driver;
    TextBoxPage textBoxPage;

    @BeforeTest
    public void setUp() {
        // Set up ChromeOptions
        ChromeOptions options = new ChromeOptions();
// Define the download folder path
        String downloadFilepath = System.getProperty("user.dir");
// Set download preferences
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("download.default_directory", downloadFilepath);
        prefs.put("download.prompt_for_download", false); // Disable download prompt
        prefs.put("safebrowsing.enabled", true); // Enable safe browsing
        options.setExperimentalOption("prefs", prefs);
        driver = new ChromeDriver(options); // local variable
        textBoxPage = new TextBoxPage(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
