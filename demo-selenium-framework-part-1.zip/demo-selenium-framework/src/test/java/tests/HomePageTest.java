package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class HomePageTest extends BaseTest {

    @Test
    public void textBoxTest() {
        driver.get("https://www.leafground.com/input.xhtml");
        textBoxPage.inputTextBox.sendKeys("hello world");
        textBoxPage.appendTextBox.sendKeys(" India");
        Assert.assertFalse(textBoxPage.disabledTextBox.isEnabled());
        textBoxPage.clearTextBox.clear();
        textBoxPage.clearTextBox.sendKeys("Hyderabad");
        System.out.println(textBoxPage.getAttributeTextBox.getDomAttribute("value"));
        textBoxPage.sendKeysTextBox.sendKeys("hello there !!!");
        textBoxPage.sendKeysTextBox.sendKeys(Keys.TAB);
    }

    @Test
    public void buttonTest() throws InterruptedException {
        driver.get("https://www.leafground.com/button.xhtml");
        driver.findElement(By.xpath("//button[@name='j_idt88:j_idt90']")).click();
        String currentUrl = driver.getCurrentUrl();
        boolean verifyUrl = currentUrl.startsWith("https://www.leafground.com/dashboard.xhtml");
        Assert.assertEquals(verifyUrl, true);

        driver.get("https://www.leafground.com/button.xhtml");
        boolean enabled = driver.findElement(By.name("j_idt88:j_idt92")).isEnabled();
        Assert.assertEquals(enabled, false);

        Point point = driver.findElement(By.id("j_idt88:j_idt94")).getLocation();
        Assert.assertEquals(point.getX(), 81);
        Assert.assertEquals(point.getY(), 400);

        String colour = driver.findElement(By.id("j_idt88:j_idt96")).getCssValue("background");
        boolean colourStatus = colour.startsWith("rgb(96, 125, 139)");
        Assert.assertEquals(colourStatus, true);

        Dimension dimension = driver.findElement(By.name("j_idt88:j_idt98")).getSize();

        Assert.assertEquals(dimension.getHeight(), 34);
        Assert.assertEquals(dimension.getWidth(), 87);

        driver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("j_idt88:j_idt107")).click();


        List<WebElement> roundedButtons = driver.findElements(By.xpath("//button[contains(@class,'rounded-button')]"));
        Assert.assertEquals(roundedButtons.size(), 4);

    }

    @Test
    public void dropDownTest() {
        driver.get("https://www.leafground.com/select.xhtml");
        WebElement selectDropDown = driver.findElement(By.xpath("//select[@class='ui-selectonemenu']"));
        // select
        Select select = new Select(selectDropDown);
        select.selectByIndex(1);
//        select.selectByValue(1);
//        select.selectByVisibleText("Cypress");
//        select.selectByContainsVisibleText("ss");

        List<WebElement> options = select.getOptions();


        for (int i = 0; i < options.size(); i++) {
            WebElement option = options.get(i);
            System.out.println(option.getText());
        }

        driver.findElement(By.id("j_idt87:country_label")).click();

        List<WebElement> divOptions = driver.findElements(By.xpath("//ul[@id=\"j_idt87:country_items\"]//li"));

        for (int i = 0; i < options.size(); i++) {
            WebElement divOption = divOptions.get(i);
            System.out.println(divOption.getText());
        }

        driver.findElement(By.xpath("//ul[@id=\"j_idt87:country_items\"]//li[text()='India']")).click();
    }

    @Test
    public void checkBoxTest() throws InterruptedException {
//        driver.get("https://www.leafground.com/checkbox.xhtml");
//        driver.findElement(By.xpath("//div[@id=\"j_idt87:j_idt91\"]//div[starts-with(@class,'ui-chkbox-box')]")).click();
//
//        Thread.sleep(1000);
//        boolean isSelected =
//                driver.findElement(By.xpath("//div[@id=\"j_idt87:j_idt91\"]//div[starts-with(@class,'ui-chkbox-box')]")).isSelected();
//
//        String afterClick = driver
//                .findElement(By.xpath("//div[@id=\"j_idt87:j_idt91\"]//div[starts-with(@class,'ui-chkbox-box')]"))
//                .getDomAttribute("class");
//
//        boolean isClicked = afterClick.contains("ui-state-active");
//        Assert.assertEquals(isClicked, true);
//        //driver.findElement(By.xpath("//div[@id=\"j_idt87:j_idt91\"]//div[starts-with(@class,'ui-chkbox-box')]")).click();
//        Thread.sleep(1000);

        driver.get("https://rahulshettyacademy.com/loginpagePractise/");
        Thread.sleep(3000);
        driver.findElement(By.id("terms")).click();
        Thread.sleep(1000);
        System.out.println(driver.findElement(By.id("terms")).isSelected());

    }

    @Test
    public void radioTest() throws InterruptedException {
        driver.get("https://rahulshettyacademy.com/loginpagePractise/");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@value =\"user\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("okayBtn")).click();

    }

    @Test
    public void linkTest() throws InterruptedException {
        driver.get("https://www.leafground.com/link.xhtml");
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//a[starts-with(@href,\"/dashboard.xhtml\")])[3]")).click();
        String currentUrl = driver.getCurrentUrl();
        boolean verifyUrl = currentUrl.startsWith("https://www.leafground.com/dashboard.xhtml");
        Assert.assertEquals(verifyUrl, true);

        driver.get("https://www.leafground.com/link.xhtml");
        List<WebElement> links = driver.findElements(By.tagName("a"));
        Assert.assertEquals(links.size(), 47);
    }

    @Test
    public void tableTest() throws InterruptedException {
        driver.get("https://www.leafground.com/table.xhtml");
        List<WebElement> headers = driver
                .findElements(By.xpath("(//div[@id=\"form:j_idt89\"]//table)[1]//tr//th//span[@class=\"ui-column-title\"]"));

        for (WebElement header : headers) {
            System.out.println(header.getText());
        }
        String inputCountry = "India";
        driver.findElement(By.id("form:j_idt89:globalFilter")).sendKeys(inputCountry);
        Thread.sleep(1000);

        List<WebElement> countries = driver.findElements(By.xpath("//tbody[@id=\"form:j_idt89_data\"]//tr//td[2]//span[3]"));

        for (WebElement country : countries) {
            Assert.assertEquals(country.getText(), inputCountry);
        }

        // List<WebElement> beforeSort -> [peter, john , adam , zack] -> TreeSet [ adam , john , peter , zack]
        // click on sort
        // List<WebElement> afterSort ->  [adam , john , peter , zack]
    }

    @Test
    public void mouseActions() {
        driver.get("https://www.leafground.com/menu.xhtml?i=1");
        Actions actions = new Actions(driver);
//        actions.contextClick(driver.findElement(By.xpath("(//form[@id=\"j_idt87\"]//div[@class=\"card\"])[6]")))
//                .click(driver.findElement(By.xpath("(//ul[@class=\"ui-menu-list ui-helper-reset\"])[8]//span[2]")))
//                .perform();


        driver.get("https://www.leafground.com/drag.xhtml");
        actions.dragAndDropBy(driver.findElement(By.id("form:conpnl")), 200, 200).perform();
        actions.dragAndDrop(driver.findElement(By.id("form:drag")), driver.findElement(By.id("form:drop")))
                .perform();
    }

    @Test
    public void fileTest() {
        driver.get("https://www.leafground.com/file.xhtml");
        driver.findElement(By.id("j_idt88:j_idt89_input"))
                .sendKeys(System.getProperty("user.dir") + "/demo.txt");
        driver.findElement(By.id("j_idt93:j_idt95")).click();
    }

    @Test
    public void alertTest() {
        driver.get("https://www.leafground.com/alert.xhtml");
        driver.findElement(By.id("j_idt88:j_idt104")).click();
        System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().sendKeys("hello");
        driver.switchTo().alert().accept();
    }

    @Test
    public void frameTest() {
        driver.get("https://www.leafground.com/frame.xhtml");
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src=\"default.xhtml\"]")));
        driver.findElement(By.id("Click")).click();
        driver.switchTo().parentFrame();
        System.out.println(driver.findElement(By.xpath("//form[@id=\"j_idt88\"]//h5")).getText());
    }

    @Test
    public void windowTest() {
        driver.get("https://www.leafground.com/window.xhtml");
        driver.findElement(By.id("j_idt88:new")).click();

        Set<String> windowHandles = driver.getWindowHandles();
        List<String> list = new ArrayList<>(windowHandles);

        driver.switchTo().window(list.get(1));
        System.out.println(driver.getCurrentUrl());
        driver.close();
        driver.switchTo().window(list.get(0));
        System.out.println(driver.getCurrentUrl());
    }

    @Test
    public void waits() throws InterruptedException {
        driver.get("https://www.leafground.com/waits.xhtml");
        driver.findElement(By.id("j_idt87:j_idt89")).click();
//        Thread.sleep(10000);
        // implicit , explicit --> explicit, fluent wait

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("j_idt87:j_idt90")));
        Assert.assertTrue(driver.findElement(By.id("j_idt87:j_idt90")).isDisplayed());
    }

}
