package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TextBoxPage {
    private WebDriver driver;

    public TextBoxPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

//    driver.findElement(By.xpath("//input[@id='j_idt88:name']")).sendKeys("hello world");

//    public By inputXpath = By.xpath("//input[@id='j_idt88:name']");
//
//    WebElement webElement = driver.findElement(inputXpath);


    @FindBy(xpath = "//input[@id='j_idt88:name']")
    public WebElement inputTextBox;

    @FindBy(xpath = "//input[@name='j_idt88:j_idt91']")
    public WebElement appendTextBox;

    @FindBy(xpath = "//input[@id='j_idt88:j_idt93']")
    public WebElement disabledTextBox;

    @FindBy(xpath = "//input[@name='j_idt88:j_idt95']")
    public WebElement clearTextBox;

    @FindBy(xpath = "//input[@id='j_idt88:j_idt97']")
    public WebElement getAttributeTextBox;

    @FindBy(name = "j_idt88:j_idt99")
    public WebElement sendKeysTextBox;



}
